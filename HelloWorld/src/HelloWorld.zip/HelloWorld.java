//Krystal-Anne Graham
//September 3, 2023
//Hello World! Java

public class HelloWorld {
	public static void main(String[] args) {
		System.out.println("Hello World!");
	}

}
